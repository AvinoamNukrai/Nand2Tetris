"""This file is part of nand2tetris, as taught in The Hebrew University,
and was written by Aviv Yaish according to the specifications given in
https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0
Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
"""
import typing

COMMENT = "/"
SPACE = " "
A_COMMAND = "A_COMMAND"
C_COMMAND = "C_COMMAND"
L_COMMAND = "L_COMMAND"
OPEN_BAR = "("
CLOSING_BAR = ")"
AT = "@"
EQ_SIGN = "="
SEMICOLON = ";"
EMPTY_STR = ""
NULL_STR = "null"
LEFT_SHIFT = "<<"
RIGHT_SHIFT = ">>"


class Parser:
    """Encapsulates access to the input code. Reads and assembly language
    command, parses it, and provides convenient access to the commands
    components (fields and symbols). In addition, removes all white space and
    comments.
    """

    def __init__(self, input_file: typing.TextIO) -> None:
        """Opens the input file and gets ready to parse it.
        Args: input_file (typing.TextIO): input file."""
        # Your code goes here!
        self.input_lines = input_file.read().splitlines()
        self.counter = 0
        # Need to remove all the background noises (Comments and Spaces)
        self.remove_comments_and_spaces()
        self.__cur_command = self.input_lines[0]  # for keeping the lines safe
        self.reach_to_end_of_file = False

    def back_to_beginning(self) -> None:
        self.__cur_command = self.input_lines[0]
        self.counter = 0

    def remove_comments_and_spaces(self) -> None:
        new_input_lines = []
        for row in self.input_lines:
            new_line = row
            new_line = new_line.replace(SPACE, EMPTY_STR)
            if COMMENT in new_line:
                if new_line.startswith(COMMENT):
                    continue
                # This is a comment coming after a line
                else:
                    new_line = new_line.split(COMMENT)
                    new_line = new_line[0]
            if len(new_line) > 0:
                # remember to check if need more checks
                new_input_lines.append(new_line)
        self.input_lines = new_input_lines

    def has_more_commands(self) -> bool:
        """Are there more commands in the input?
        Returns: bool - True if there are more commands, False otherwise."""
        # Your code goes here!
        if self.counter < len(self.input_lines):
            return True
        return False

    def advance(self) -> None:
        """Reads the next command from the input and makes it the current
        command. Should be called only if has_more_commands() is true. """
        # Your code goes here!
        self.counter += 1
        if self.has_more_commands():
            self.__cur_command = self.input_lines[self.counter]
            return
        self.reach_to_end_of_file = True

    def command_type(self) -> str:
        """
        Returns:
            str: the type of the current command:
            "A_COMMAND" for @Xxx where Xxx is either a symbol or a decimal number
            "C_COMMAND" for dest=comp;jump
            "L_COMMAND" (actually, pseudo-command) for (Xxx) where Xxx is a symbol
        """
        # Your code goes here!
        if self.__cur_command[0] == AT:
            return A_COMMAND
        if self.__cur_command[0] == OPEN_BAR:
            return L_COMMAND
        return C_COMMAND  # we can assume validation of the input_file

    def symbol(self) -> str:
        """
        Returns:
            str: the symbol or decimal Xxx of the current command @Xxx or
            (Xxx). Should be called only when command_type() is "A_COMMAND" or
            "L_COMMAND".
        """
        # Your code goes here!
        if self.command_type() == A_COMMAND:
            return self.__cur_command[1:]
        if self.command_type() == L_COMMAND:
            return self.__cur_command[1:-1]

    def dest(self) -> str:
        """
        Returns:
            str: the dest mnemonic in the current C-command. Should be called
            only when commandType() is "C_COMMAND".
        """
        # Your code goes here!
        if self.command_type() == C_COMMAND:
            if EQ_SIGN in self.__cur_command:
                return self.__cur_command.split(EQ_SIGN)[0]
        return NULL_STR  # no dest but jump condition

    def comp(self) -> str:
        """
        Returns:
            str: the comp mnemonic in the current C-command. Should be called
            only when commandType() is "C_COMMAND".
        """
        # Your code goes here!
        if EQ_SIGN in self.__cur_command:
            after_eq = self.__cur_command.split(EQ_SIGN)[1]
            if SEMICOLON in after_eq:
                return after_eq.split(SEMICOLON)[0]
            return after_eq
        if SEMICOLON in self.__cur_command:
            return self.__cur_command.split(SEMICOLON)[0]
        return EMPTY_STR  # No comp command (we assume that the all commands in file is valid)

    def jump(self) -> str:
        """
        Returns:
            str: the jump mnemonic in the current C-command. Should be called
            only when commandType() is "C_COMMAND".
        """
        # Your code goes here!
        if SEMICOLON in self.__cur_command:
            return self.__cur_command.split(SEMICOLON)[1]
        if EQ_SIGN in self.__cur_command:
            after_eq = self.__cur_command.split(EQ_SIGN)[1]
            if SEMICOLON in after_eq:
                return after_eq.split(SEMICOLON)[1]
        return NULL_STR
