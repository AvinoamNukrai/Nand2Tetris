import re
from enum import Enum


class Parser:
    """
    Handles the parsing of a single .vm file, and encapsulates access to the input code. It reads VM
    commands, parses them, and provides convenient access to their components. In addition, it removes all
    white space and comments.
    """
    Cmd_Type = Enum('type', 'C_ARITHMETIC C_POP C_PUSH C_LABEL C_GOTO C_IF C_FUNCTION C_RETURN C_CALL')

    def __init__(self, file_name):
        """
        opens the input file and delete empty lines and comments
        and saves the file as a list of lines.
        """
        self.__lines = []
        self.__countCmd = -1
        self.__arg1 = self.__arg2 = -1
        with open(file_name) as file:
            for line in file:
                line = re.sub(re.compile(r'//.*'), "", line).lstrip().rstrip()
                if not (not line or line.isspace()):
                    self.__lines.append(line)

    def has_more_commands(self):
        """
        check if there are more commands in the input file
        """
        return (self.__countCmd+1) < len(self.__lines)

    def advance(self):
        """
        return the current line.
        """
        self.__countCmd += 1
        return self.__lines[self.__countCmd]

    def command_type(self):
        """
        return the type of the command (arithmetic, pop, push, label, goto,
                                        if, function, return, call)
        """
        line = self.__lines[self.__countCmd]

        # check arithmetic
        arithmetic = ['add', 'sub', 'neg', 'eq', 'gt', 'lt', 'and', 'or', 'not']
        if line in arithmetic:
            self.__arg1 = line
            return Parser.Cmd_Type.C_ARITHMETIC

        # check pop/push
        res = re.compile(r'(pop|push)\s+(\w+)\s+(\w+)').match(line)
        if res:
            self.__arg1 = res.group(2); self.__arg2 = int(res.group(3))
            if res.group(1) == "pop":
                return Parser.Cmd_Type.C_POP
            else:
                return Parser.Cmd_Type.C_PUSH

        # check label
        res = re.compile(r'(label)\s+([\w:.]+)').match(line)
        if res:
            self.__arg1 = res.group(2)
            return Parser.Cmd_Type.C_LABEL

        # check goto
        res = re.compile(r'(goto)\s+([\w:.]+)').match(line)
        if res:
            self.__arg1 = res.group(2)
            return Parser.Cmd_Type.C_GOTO

        # check if
        res = re.compile(r'(if-goto)\s+([\w:.]+)').match(line)
        if res:
            self.__arg1 = res.group(2)
            return Parser.Cmd_Type.C_IF

        # check function
        res = re.compile(r'(function)\s+([\w.]+)\s+(\d+)').match(line)
        if res:
            self.__arg1 = res.group(2); self.__arg2 = int(res.group(3))
            return Parser.Cmd_Type.C_FUNCTION

        # check return
        res = re.compile(r'(return)').match(line)
        if res:
            return Parser.Cmd_Type.C_RETURN

        # check call
        res = re.compile(r'(call)\s+([\w.]+)\s+(\d+)').match(line)
        if res:
            self.__arg1 = res.group(2); self.__arg2 = int(res.group(3))
            return Parser.Cmd_Type.C_CALL

    def arg1(self):
        """
        return the first argument of command.
        """
        return self.__arg1

    def arg2(self):
        """
        return the second argument of command.
        """
        return self.__arg2







