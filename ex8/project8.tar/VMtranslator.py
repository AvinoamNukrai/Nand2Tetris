import sys, os, os.path, glob
from Parser import Parser
from CodeWriter import CodeWriter

class VMtranslator:
    def __init__(self, path):
        self.__path = path

    def translate(self):
        if self.__path.endswith('.vm'):
            files = [self.__path]; out_name = self.__path.replace('.vm', '.asm')
        else:
            if self.__path.endswith('/'):
                self.__path = self.__path[:-1]
            files = glob.glob(self.__path+'/*.vm')
            out_name = self.__path + "/" + os.path.basename(self.__path) + ".asm"

        code_writer = CodeWriter(out_name)
        code_writer.write_init()
        for file in files:
            parser = Parser(file)
            code_writer.set_file_name(os.path.basename(file))
            while parser.has_more_commands():
                line = parser.advance()
                cmd_type = parser.command_type()
                arg1 = parser.arg1()
                arg2 = parser.arg2()
                if cmd_type == Parser.Cmd_Type.C_ARITHMETIC:
                    code_writer.write_arithmetic(line)

                elif cmd_type == Parser.Cmd_Type.C_POP:
                    code_writer.write_push_pop(cmd_type, arg1, arg2)

                elif cmd_type == Parser.Cmd_Type.C_PUSH:
                    code_writer.write_push_pop(cmd_type, arg1, arg2)

                elif cmd_type == Parser.Cmd_Type.C_LABEL:
                    code_writer.write_label(arg1)

                elif cmd_type == Parser.Cmd_Type.C_GOTO:
                    code_writer.write_goto(arg1)

                elif cmd_type == Parser.Cmd_Type.C_IF:
                    code_writer.write_if(arg1)

                elif cmd_type == Parser.Cmd_Type.C_FUNCTION:
                    code_writer.write_function(arg1, arg2)

                elif cmd_type == Parser.Cmd_Type.C_CALL:
                    code_writer.write_call(arg1, arg2)

                elif cmd_type == Parser.Cmd_Type.C_RETURN:
                    code_writer.write_return()

        code_writer.close()


def main(file_name):
    vm_translator = VMtranslator(file_name)
    vm_translator.translate()

if __name__ == "__main__":
    main(sys.argv[1])