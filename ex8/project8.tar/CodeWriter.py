# """This file is part of nand2tetris, as taught in The Hebrew University,
# and was written by Aviv Yaish according to the specifications given in
# https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
# and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0
# Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
# """
import typing

# Written by Avinoam Nukrai, Hebrew U winter 2021




WRITE_TO_STACK_STR = \
"""
//Writes to the first available slot in the stack and updating the stack's pointer
@SP
A = M
M = D
@SP
M = M+1
 """

POP_AND_ADVANCE = \
"""
//Pooping
@SP
A = M - 1
D = M
@{reg}
{double_slash}A = M
M = D

//Lekadem mahsanit
@SP
M = M-1
"""


POP_AND_SHIFT = \
POP_AND_ADVANCE.format(reg="R14", double_slash="//") + \
"""
@{reg}
D = M{symbol}
""" + WRITE_TO_STACK_STR



from Parser import Parser


class CodeWriter:
    def __init__(self, out_file):
        self.__translation = []
        self.__out_file = open(out_file, 'w')
        self.__cur_file = None
        self.__counter = 0
        self.__function_counter = 0
        self.__func_name = ""

    def write_init(self):
        asm_string = '@256\n' \
                     'D=A\n' \
                     '@SP\n' \
                     'M=D\n'
        self.__out_file.write(asm_string)
        self.write_call('Sys.init', 0)

    def set_file_name(self, name):
        self.__cur_file = name

    def write_arithmetic(self, command):
        """
        write the assembly code that is the translation of the given
        arithmetic command
        """
        binary_arithmetic = {'add': '+', 'sub': '-', 'and': '&', 'or':'|'}
        comparison = {'eq': 'JEQ', 'gt': 'JGT', 'lt': 'JLT'}
        unary_arithmetic = {'neg': '-', 'not': '!'}
        shifts_dict = {"shiftright": ">>", "shiftleft": "<<"}

        if command in binary_arithmetic.keys():
            self._binary_op(binary_arithmetic[command])

        elif command in comparison.keys():
            dic = {'gt': ('JGT', 1, 0), 'lt': ('JLT', 0, 1), 'eq': ('JEQ', 0, 0)}
            self._compare(dic[command][0], dic[command][1], dic[command][2])
        elif command in shifts_dict.keys():
            command_val = shifts_dict[command]
            self.shifts_translator(command_val)

        else:  # unary
            self._unary_op(unary_arithmetic[command])

    def shifts_translator(self, symbol):
        asm_command = POP_AND_SHIFT.format(reg="R14", symbol=symbol)
        self.__out_file.write(asm_command)

    def write_push_pop(self, command, segment, index):
        """
        writes the assembly code that is the translation of the given
        pop/push command
        """
        if command == Parser.Cmd_Type.C_PUSH:
            self._push(segment, index)

        elif command == Parser.Cmd_Type.C_POP:
            self._pop(segment, index)

    def write_label(self, label):
        """
        writes the assemble code that is the translation of the given 'label' command.
        """
        asm_string = "(" + self.__func_name + "$" + label + ")\n"
        self.__out_file.write(asm_string)

    def write_goto(self, label):
        """
        writes the assembly code that is the translation of the give 'goto' command.
        """
        asm_string = '@' + self.__func_name + "$" + label + '\n' \
                     '0;JMP\n'
        self.__out_file.write(asm_string)

    def write_if(self, label):
        """
        writes the assembly code that that is the translation of the given 'if-goto' command
        """
        asm_string = '@SP\n' \
                     'AM=M-1\n' \
                     'D=M\n' \
                     '@' + self.__func_name + "$" + label + '\n' \
                     'D;JNE\n'
        self.__out_file.write(asm_string)

    def close(self):
        """
        close the output file and end the assembly program with infinity loop.
        """
        self.__out_file.close()

    def write_call(self, func_name, args_num):
        """
        writes the assembly cide that is the translation
        if the given 'call' command
        """
        return_address = 'RETURN_ADDRESS' + str(self.__function_counter)
        asm_string = "@" + return_address + "\nD=A\n@SP\nA=M\nM=D\n@SP\nM=M+1\n"
        self.__out_file.write(asm_string)
        self._push_constant('LCL')
        self._push_constant('ARG')
        self._push_constant('THIS')
        self._push_constant('THAT')
        asm_string = '@SP\n' \
                     'D=M\n' \
                     '@' + str(args_num+5) + '\n' \
                     'D=D-A\n' \
                     '@ARG\n' \
                     'M=D\n' \
                     '@SP\n' \
                     'D=M\n' \
                     '@LCL\n' \
                     'M=D\n' \
                     '@' + func_name + '\n' \
                     '0;JMP\n' \
                     '(' + return_address + ')\n'
        self.__out_file.write(asm_string)
        self.__function_counter += 1

    def write_function(self, function_name, num_locals):
        """
        writes the assembly code that is the translation of the given
        'function' command.
        """
        self.__func_name = function_name
        asm_string = '(' + function_name + ')\n'
        self.__out_file.write(asm_string)
        for i in range(num_locals):
            self.__out_file.write('@SP\nM=M+1\nA=M-1\nM=0\n')

    def write_return(self):
        """
        writes the assembly code that is the translation of the given
        'return' command
        """
        asm_string = '@LCL\nD=M\n@R13\nM=D\n'
        asm_string += '@5\nD=A\n@R13\nD=M-D\nA=D\nD=M\n@R14\nM=D\n'
        asm_string += '@SP\nAM=M-1\nD=M\n@ARG\nA=M\nM=D\n'
        asm_string += '@ARG\nD=M\n@SP\nM=D+1\n'
        asm_string += '@R13\nM=M-1\nA=M\nD=M\n@THAT\nM=D\n'
        asm_string += '@R13\nM=M-1\nA=M\nD=M\n@THIS\nM=D\n'
        asm_string += '@R13\nM=M-1\nA=M\nD=M\n@ARG\nM=D\n'
        asm_string += '@R13\nM=M-1\nA=M\nD=M\n@LCL\nM=D\n'
        asm_string += '@R14\nA=M\n0;JMP\n'
        self.__out_file.write(asm_string)

    # ======================== Helper Functions================================

    def _push(self, segment, index):
        """
        push to the stack the value which is found in the segment memory
        in the given index.
        """
        push_option1 = {'argument': 'ARG', 'local': 'LCL', 'this': 'THIS', 'that': 'THAT'}
        push_option2 = {'pointer': 3, 'temp': 5, 'free': 13}
        asm_string = None
        if segment in push_option1:
            asm_string = '@'+str(index)+'\n' \
                         'D=A\n' \
                         '@'+push_option1[segment]+'\n'\
                         'A=D+M\n' \
                         'D=M\n' \

        if segment in push_option2:
            ram = push_option2[segment] + index
            asm_string = '@'+str(ram)+'\n' \
                         'D=M\n'

        if segment == "constant":
            asm_string = '@'+str(index)+'\n' \
                         'D=A\n'

        if segment == "static":
            var_name = self.__cur_file + "." + str(index)
            asm_string = '@'+var_name+'\n' \
                         'D=M\n'

        asm_string += '@SP\n' \
                      'A=M\n' \
                      'M=D\n' \
                      '@SP\n' \
                      'M=M+1\n'

        self.__out_file.write(asm_string)

    def _pop(self, segment, index):
        """
         Pop the topmost value at the stack into the segment memory
         in the given index
        """
        pop_option1 = {'argument': 'ARG', 'local': 'LCL', 'this': 'THIS', 'that': 'THAT'}
        pop_option2 = {'pointer': 3, 'temp': 5, 'free': 13}
        asm_string = '@SP\n' \
                     'M=M-1\n' \
                     'A=M\n' \
                     'D=M\n' \
                     'M=0\n' \
                     '@R13\n' \
                     'M=D\n'

        if segment in pop_option1:
            asm_string += '@'+pop_option1[segment]+'\n' \
                          'D=M\n' \
                          '@'+str(index)+'\n' \
                          'D=D+A\n' \
                          '@R14\n' \
                          'M=D\n' \
                          '@R13\n' \
                          'D=M\n' \
                          '@R14\n' \
                          'A=M\n' \
                          'M=D\n'

        if segment in pop_option2:
            ram = pop_option2[segment] + index
            asm_string += '@R13\n' \
                          'D=M\n' \
                          '@'+str(ram)+'\n' \
                          'M=D\n'

        if segment == "static":
            var_name = self.__cur_file + "." + str(index)
            asm_string += '@R13\n' \
                          'D=M\n' \
                          '@'+var_name+'\n' \
                          'M=D\n'

        self.__out_file.write(asm_string)

    def _binary_op(self, binary_op):
        """
        write the assembly code of a binary arithmetic operation
        :param binary_op: the operation(+,-,&,|)
        """
        asm_string = '@SP\n' \
                     'M=M-1\n' \
                     'A=M-1\n' \
                     'D=M\n' \
                     'A=A+1\n' \
                     'M=D'+binary_op+'M\n' \
                     'D=M\n' \
                     'M=0\n' \
                     'A=A-1\n' \
                     'M=D\n'

        self.__out_file.write(asm_string)

    def _unary_op(self, unary_op):
        """
        write the assembly code of a unary arithmetic operation
        :param unary_op: the operation(-, !)
        """
        asm_string = '@SP\n' \
                     'A=M-1\n' \
                     'M=' + unary_op + 'M\n'
        self.__out_file.write(asm_string)

    def _trivial_compare(self, kind):
        """
        perform 'eq'/'gt'/'lt' operation on the two topmost values of stack
        kind = JEQ for eq, JGT  for gt and JLT for lt
        """
        self._binary_op('-')
        first_label = str(self._label_counter())
        second_label = str(self._label_counter())
        asm_string = '@SP\n' \
                     'A=M-1\n' \
                     'D=M\n' \
                     '@TRUE' + first_label + '\n' \
                     'D;' + kind + '\n' \
                     '@SP\n'\
                     'A=M-1\n'\
                     'M=0\n' \
                     '@END' + second_label + '\n' \
                     '0;JMP\n' \
                     '(TRUE'+first_label + ')\n' \
                     '@SP\n'\
                     'A=M-1\n'\
                     'M=-1\n'\
                     '(END'+second_label+')\n'
        self.__out_file.write(asm_string)

    def _compare(self, oper, sign1, sign2):
        labelAnegate = '$' + str(self._label_counter())
        labelBnegate = '$' + str(self._label_counter())
        labelEND = '$' + str(self._label_counter())
        labelBnegate2 = '$' + str(self._label_counter())

        self._pop('free', 2)
        self._pop('free', 1)
        self._push('free', 1)
        self._push('free', 2)

        asm_string1 = '@R14\n' \
                      'D=M\n' \
                      '@' + labelAnegate +'\n' \
                      'D;JLE\n' \
                      '@R15\n' \
                      'D=M\n' \
                      '@' + labelBnegate + '\n' \
                      'D;JLE\n'

        self.__out_file.write(asm_string1)

        self._trivial_compare(oper)

        asm_string2 = '@' + labelEND + '\n' \
                      '0;JMP\n' \
                      '(' + labelBnegate + ')\n'

        self.__out_file.write(asm_string2)

        self._pop('free', 0)
        self._pop('free', 0)
        self._push('constant', sign1)
        self.write_arithmetic('neg')

        asm_string3 = '@' + labelEND + '\n' \
                      '0;JMP\n' \
                      '(' + labelAnegate + ')\n' \
                      '@R15\nD=M\n' \
                      '@' + labelBnegate2 + '\n' \
                      'D;JLE\n'

        self.__out_file.write(asm_string3)
        self._pop('free', 0)
        self._pop('free', 0)

        self._push('constant', sign2)
        self.write_arithmetic('neg')

        asm_string4 = '@' + labelEND + '\n' \
                      '0;JMP\n' \
                      '(' + labelBnegate2 + ')\n'

        self.__out_file.write(asm_string4)

        self._trivial_compare(oper)
        asm_string5 = '@' + labelEND + '\n' \
                      '0;JMP\n' \
                      '(' + labelEND + ')\n'
        self.__out_file.write(asm_string5)

    def _label_counter(self):
        """Advance the label counter and return it."""
        self.__counter += 1
        return self.__counter

    def _push_constant(self, const):
        """
        pushes the value from Ram[const] to the stack.
        """
        asm_string = '@'+str(const)+'\n' \
                     'D=M\n' \
                     '@SP\n' \
                     'A=M\n' \
                     'M=D\n' \
                     '@SP\n' \
                     'M=M+1\n'
        self.__out_file.write(asm_string)


