# """This file is part of nand2tetris, as taught in The Hebrew University,
# and was written by Aviv Yaish according to the specifications given in
# https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
# and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0
# Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
# """
import typing

# Written by Avinoam Nukrai, Hebrew U winter 2021

from Parser import Parser, C_ARITHMETIC, C_POP, C_PUSH


class CodeWriter:
    def __init__(self, output_stream: typing.TextIO) -> None:
        """Initializes the CodeWriter.

        Args:
            output_stream (typing.TextIO): output stream.
        """
        # Your code goes here!
        self.__out_file = output_stream
        self.__cur_file = None
        self.__counter = 0

    def write_init(self):
        # write the first line in the assembly file
        asm_string = '@256\n' \
                     'D=A\n' \
                     '@SP\n' \
                     'M=D\n'
        self.__out_file.write(asm_string)

    def set_file_name(self, filename: str) -> None:
        """Informs the code writer that the translation of a new VM file is
        started.

        Args:
            filename (str): The name of the VM file.
        """
        self.__cur_file = filename

    def write_arithmetic(self, command: str) -> None:
        """Writes the assembly code that is the translation of the given
        arithmetic command.

        Args:
            command (str): an arithmetic command.
        """
        # Your code goes here!
        binary_arithmetic = {'add': '+', 'sub': '-', 'and': '&', 'or':'|'}
        comparison = {'eq': 'JEQ', 'gt': 'JGT', 'lt': 'JLT'}
        unary_arithmetic = {'neg': '-', 'not': '!'}
        shifts_dict = {"shiftright": ">>", "shiftleft": "<<"}

        if command in binary_arithmetic.keys():
            self.binary_translator(binary_arithmetic[command])

        elif command in comparison.keys():
            self.compare_translator(comparison[command])

        elif command in shifts_dict.keys():
            command_val = shifts_dict[command]
            self.shifts_translator(command_val)

        else:  # unary
            self.unary_translator(unary_arithmetic[command])

    def write_push_pop(self, command: str, segment: str, index: int) -> None:
        """Writes the assembly code that is the translation of the given
        command, where command is either C_PUSH or C_POP.

        Args:
            command (str): "C_PUSH" or "C_POP".
            segment (str): the memory segment to operate on.
            index (int): the index in the memory segment.
        """
        # Your code goes here!
        if command == C_PUSH:
            self._push(segment, index)

        elif command == C_POP:
            self._pop(segment, index)

    # ======================== Helper Functions================================

    def shifts_translator(self, symbol):
        asm_command = POP_AND_SHIFT.format(reg="R14",
                             symbol=symbol)
        self.__out_file.write(asm_command)

    def _push(self, segment, index):
        """
        push to the stack the value which is found in the segment memory
        in the given index.
        """
        push_option1 = {'argument': 'ARG', 'local': 'LCL', 'this': 'THIS',
                        'that': 'THAT'}
        push_option2 = {'pointer': 3, 'temp': 5}
        asm_string = None
        if segment in push_option1:
            asm_string = '@'+str(index)+'\n' \
                         'D=A\n' \
                         '@'+push_option1[segment]+'\n'\
                         'A=D+M\n' \
                         'D=M\n' \

        if segment in push_option2:
            ram = push_option2[segment] + index
            asm_string = '@'+str(ram)+'\n' \
                         'D=M\n'

        if segment == "constant":
            asm_string = '@'+str(index)+'\n' \
                         'D=A\n'

        if segment == "static":
            var_name = self.__cur_file + "." + str(index)
            asm_string = '@'+var_name+'\n' \
                         'D=M\n'

        asm_string += '@SP\n' \
                      'A=M\n' \
                      'M=D\n' \
                      '@SP\n' \
                      'M=M+1\n'

        self.__out_file.write(asm_string)

    def _pop(self, segment, index):
        """
         Pop the topmost value at the stack into the segment memory
         in the given index
        """
        pop_option1 = {'argument': 'ARG', 'local': 'LCL', 'this': 'THIS',
                       'that': 'THAT'}
        pop_option2 = {'pointer': 3, 'temp': 5}
        asm_string = '@SP\n' \
                     'M=M-1\n' \
                     'A=M\n' \
                     'D=M\n' \
                     'M=0\n' \
                     '@R13\n' \
                     'M=D\n'

        if segment in pop_option1:
            asm_string += '@'+pop_option1[segment]+'\n' \
                          'D=M\n' \
                          '@'+str(index)+'\n' \
                          'D=D+A\n' \
                          '@R14\n' \
                          'M=D\n' \
                          '@R13\n' \
                          'D=M\n' \
                          '@R14\n' \
                          'A=M\n' \
                          'M=D\n'

        if segment in pop_option2:
            ram = pop_option2[segment] + index
            asm_string += '@R13\n' \
                          'D=M\n' \
                          '@'+str(ram)+'\n' \
                          'M=D\n'

        if segment == "static":
            var_name = self.__cur_file + "." + str(index)
            asm_string += '@R13\n' \
                          'D=M\n' \
                          '@'+var_name+'\n' \
                          'M=D\n'

        self.__out_file.write(asm_string)

    def binary_translator(self, binary_op):
        """
        write the assembly code of a binary arithmetic operation
        :param binary_op: the operation(+,-,&,|)
        """
        asm_string = '@SP\n' \
                     'M=M-1\n' \
                     'A=M-1\n' \
                     'D=M\n' \
                     'A=A+1\n' \
                     'M=D'+binary_op+'M\n' \
                     'D=M\n' \
                     'M=0\n' \
                     'A=A-1\n' \
                     'M=D\n'

        self.__out_file.write(asm_string)

    def unary_translator(self, unary_op):
        """
        write the assembly code of a unary arithmetic operation
        :param unary_op: the operation(-, !)
        """
        asm_string = '@SP\n' \
                     'A=M-1\n' \
                     'M=' + unary_op + 'M\n'
        self.__out_file.write(asm_string)

    def compare_translator(self, kind):
        """
        perform 'eq'/'gt'/'lt' operation on the two topmost values of stack
        kind = JEQ for eq, JGT  for gt and JLT for lt
        """
        self.binary_translator('-')
        first_label = str(self._label_counter())
        second_label = str(self._label_counter())
        asm_string = '@SP\n' \
                     'A=M-1\n' \
                     'D=M\n' \
                     '@TRUE' + first_label + '\n' \
                     'D;' + kind + '\n' \
                     '@SP\n'\
                     'A=M-1\n'\
                     'M=0\n' \
                     '@END' + second_label + '\n' \
                     '0;JMP\n' \
                     '(TRUE'+first_label + ')\n' \
                     '@SP\n'\
                     'A=M-1\n'\
                     'M=-1\n'\
                     '(END'+second_label+')\n'
        self.__out_file.write(asm_string)

    def _label_counter(self):
        """Advance the label counter and return it."""
        self.__counter += 1
        return self.__counter

    def close(self):
        self.__out_file.close()



WRITE_TO_STACK_STR = \
"""
//Writes to the first available slot in the stack and updating the stack's pointer
@SP
A = M
M = D
@SP
M = M+1
 """

POP_AND_ADVANCE = \
"""
//Pooping
@SP
A = M - 1
D = M
@{reg}
{double_slash}A = M
M = D

//Lekadem mahsanit
@SP
M = M-1
"""


POP_AND_SHIFT = \
POP_AND_ADVANCE.format(reg="R14", double_slash="//") + \
"""
@{reg}
D = M{symbol}
""" + WRITE_TO_STACK_STR

