# """This file is part of nand2tetris, as taught in The Hebrew University,
# and was written by Aviv Yaish according to the specifications given in
# https://www.nand2tetris.org (Shimon Schocken and Noam Nisan, 2017)
# and as allowed by the Creative Common Attribution-NonCommercial-ShareAlike 3.0
# Unported License (https://creativecommons.org/licenses/by-nc-sa/3.0/).
# """
import typing

# Constants
SPACE = " "
EMPTY_STR = ""
COMMENT = "/"
ASM = ".asm"

# arithmetic commands
ADD = "add"
SUB = "sub"
NEG = "neg"
EQ = "eq"
GT = "gt"
LT = "lt"
AND = "and"
OR = "or"
NOT = "not"

LCL = "LCL"
ARG = "ARG"
THIS = "THIS"
THAT = "THAT"
CONSTANT = "constant"
STATIC = "static"
TEMP = "temp"
POINTER = "pointer"

# commands
PUSH = "push"
POP = "pop"
LABEL = '('
IF = "if"
FUNCTION = "function"
RETURN = "return"
CALL = "call"

# other
C_ARITHMETIC = "C_ARITHMETIC"
C_PUSH = "C_PUSH"
C_POP = "C_POP"
C_LABEL = "C_LABEL"
C_IF = "C_IF"
C_FUNCTION = "C_FUNCTION"
C_RETURN = "C_RETURN"
C_CALL = "C_CALL"


class Parser:
    """
    Handles the parsing of a single .vm file, and encapsulates access to the
    input code. It reads VM commands, parses them, and provides convenient
    access to their components.
    In addition, it removes all white space and comments.
    """

    def __init__(self, input_file: typing.TextIO) -> None:
        """Gets ready to parse the input file.

        Args:
            input_file (typing.TextIO): input file.
        """
        # Your code goes here!
        self.input_lines = input_file.read().splitlines() # parsing the file
        self.counter = 0
        self.remove_comments_and_spaces()
        self.__cur_commend = self.input_lines[self.counter]
        self.reach_the_end_of_the_file = False

    def remove_comments_and_spaces(self):
        """This method is cleaning the input of the input_file from all
         background  noises such as comments and white spaces.
         praram: None - works on the self.input_lines
         return: None
        """
        new_input_lines = []
        for row in self.input_lines:
            new_line = row
            if COMMENT in new_line:
                if new_line.startswith(COMMENT):
                    continue
                # This is a comment coming after a line
                else:
                    new_line = new_line.split(COMMENT)[0]
            if len(new_line) > 0:
                new_input_lines.append(new_line)
        self.input_lines = new_input_lines

    def has_more_commands(self) -> bool:
        """Are there more commands in the input?

        Returns:
            bool: True if there are more commands, False otherwise.
        """
        # Your code goes here!
        if self.counter < len(self.input_lines):
            return True
        return False

    def advance(self) -> None:
        """Reads the next command from the input and makes it the current
        command. Should be called only if has_more_commands() is true. Initially
        there is no current command.
        """
        # Your code goes here!
        self.counter += 1
        if self.has_more_commands():
            self.__cur_commend = self.input_lines[self.counter]
            return
        self.reach_the_end_of_the_file = True

    def command_type(self) -> str:
        """
        Returns:
            str: the type of the current VM command.
            "C_ARITHMETIC" is returned for all arithmetic commands.
            For other commands, can return:
            "C_PUSH", "C_POP", "C_LABEL", "C_GOTO", "C_IF", "C_FUNCTION",
            "C_RETURN", "C_CALL".
        """
        # Your code goes here!
        if PUSH in self.__cur_commend:
            return C_PUSH
        elif POP in self.__cur_commend:
            return C_POP
        elif LABEL in self.__cur_commend:
            return C_LABEL
        elif IF in self.__cur_commend:
            return C_IF
        elif FUNCTION in self.__cur_commend:
            return C_FUNCTION
        elif RETURN in self.__cur_commend:
            return C_RETURN
        elif CALL in self.__cur_commend:
            return C_CALL
        else:
            return C_ARITHMETIC

    def arg1(self) -> str:
        """
        Returns:
            str: the first argument of the current command. In case of
            "C_ARITHMETIC", the command itself (add, sub, etc.) is returned.
            Should not be called if the current command is "C_RETURN".
        """
        # Your code goes here!
        sub_command = self.__cur_commend.split()
        if self.command_type() is C_ARITHMETIC:
            return sub_command[0]
        return sub_command[1]

    def arg2(self) -> int:
        """
        Returns:
            int: the second argument of the current command. Should be
            called only if the current command is "C_PUSH", "C_POP",
            "C_FUNCTION" or "C_CALL".
        """
        # Your code goes here!
        if self.command_type() == C_PUSH or self.command_type() == C_POP or \
            self.command_type() == C_FUNCTION or self.command_type() == C_CALL:
            return int(self.__cur_commend.split()[2])

    def get_cur_command(self):
        """returns the current command of the program"""
        return self.__cur_commend
